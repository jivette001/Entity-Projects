library("rcompanion")
library("car")
library("effects")
library("multcomp")
library('carData')

NaRV.omit(cellPhone)
plotNormalHistogram(cellPhone$Night.Mins)
#the graph looks good 
leveneTest(Night.Mins~International.Plan, data=cellPhone)

Homogeneity_RegrSlp = lm(Night.Mins~vMail.Plan, data=cellPhone)
anova(Homogeneity_RegrSlp)

ANCOVA = lm(Night.Mins~vMail.Plan + International.Plan*vMail.Plan, data=cellPhone)
anova(ANCOVA)