library("mvnormtest")
library("car")
library('rcompanion')
install.packages("vembedr")
library("vembedr")
install.packages("mvnormtest")
install.packages("car")
install.packages("plyr")
install.packages("ggplot2")

na.omit(heartAttacks)
str(heartAttacks$trestbps)
str(heartAttacks$chol)

keeps <- c('trestbps','chol','sex')
hearts <- heartAttacks[keeps]

hearts1<- hearts[1:1000,]

#formatting data as a Matrix
hearts2<- as.matrix(hearts1)

head(hearts2)

plotNormalHistogram(hearts2)

hearts3<-na.omit(hearts2)
head(hearts3)

mshapiro.test(t(hearts3))

leveneTest(heartAttacks$'chol', heartAttacks$'sex', data=heartAttacks)
leveneTest(heartAttacks$'trestbps', heartAttacks$'sex', data=heartAttacks)

cor.test(heartAttacks$chol, heartAttacks$trestbps, method='pearson',use='complete.obs')
cor.test(heartAttacks$sex, heartAttacks$trestbps, method='pearson',use='complete.obs')

MANOVA<-manova(cbind(chol,trestbps)~sex,data=heartAttacks)
summary(MANOVA)

summary.aov(MANOVA, test='wilks')
