# part 1 Stepwise Regression

qall <- lm(IQ ~ ., data = IQ)
summary(qall)
#backwards elimination
step(qall, direction = 'backward')

#summarize models
q2 = lm(formula = IQ ~ Test1 + Test2 + Test4, data = IQ)
summary(q2)
# the F-statistic is low 

#part2

# backward set up
qall = lm(Y ~ ., data = stepwiseRegression)
summary(qall)

# run the backward elimination
step(qall, direction = 'backward')

# summarize model to see if it is any good
qall = lm(formula = Y ~ X2 + X4 + X6 + X10 + X11 + X12, data = stepwiseRegression)
summary(qall)
# This model is very significant, and accounts for 99.98% of the variation of Y

# forward set up
qall1= lm(Y ~ 1, data = stepwiseRegression)
summary(qall)

# run the forward selection
step(qall, directrion = 'forward', scope = (formula(qall)))

# summarise the model to see if it is any good
qall= lm(formula = Y ~ X6 + X4 + X12 + X10 + X2 + X11, data = stepwiseRegression)
summary(qall)
# This model is very significant, and accounts for 99.98% of the variation of Y
# This model also contains all of the IVs from the backward elimination model, just
# in a different order

# stepwise setup
step(qall, directrion = 'both', scope = (formula(fitall)))
qall = lm(formula = Y ~ X6 + X4 + X12 + X10 + X2 + X11, data = stepwiseRegression)
summary(qall)
# Same ass the previous models, same variables too