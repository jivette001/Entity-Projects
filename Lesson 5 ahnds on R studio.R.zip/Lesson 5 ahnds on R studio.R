#Getting Random numbers
runif(100, 0, 1)

#cost 
cost<- runif(100,26.33,33.72)

#graphing Cost
hist(runif(100,26.88,33.72),freq = F)

# units sold
unitssold=rnorm(100,26,5.7)
print(unitssold)

#graphing units sold 
hist(rnorm(100,26,5.7),freq = F)

#Resource Factor
RF=rnorm(100,3,1.2)
print(RF)

#graph RF
hist(rnorm(100,3,1.2), freq = F)

#price Discrete distribution. 55% of the time the price is 38 dollars, 
# 30% of the time the price is 41.50 dollars, and 15% of the time is 36.25 dollars.
df=data.frame(DataframeP)
df$price<- DataframeP
head(df$price)

#if code
for (p in df$price) {
  print(p)
}

for (p in df$price) {
  if (p < .15)
    36.25
  else if (p < .45)
    41.50
  else {38}
}

head(df$price1)

df$price1 = if (df$price < .15) {36.25
  }else if (df$price < .45)
  {41.5
  }else {38} 

#create generate numbers to DataframeP
df <- data.frame(DataframeP)

#attach each column to data

df$units_sold <- units_sold
df$cost <- cost
df$rf <- rf

head(df)

#Calculting Price
profit = function(df) 
  {(rf)* (units_sold) * (price) - ((0.2) * (rf)  * (units_sold) * (cost)) + 320}

df$price = DataframeP





