install.packages('tidyverse')
install.packages("rcompanion")
install.packages('car')
install.packages('ggplot')
install.packages('tibble')
install.packages('forcats')
install.packages('carData')
install.packages('recode')
install.packages('some')
install.packages('plotNormalHistogram')
install.packages('ggplot2')
library(tidyverse)
library(rcompanion)
library(car)
library(readr)
avocados <- read_csv("Downloads/avocados.csv")
View(avocados)

head(avocados)
#data wrangling 

avo<-na.omit(avocados %>% filter(region %in% c('Albany','Houston','Seattle')))
#making price numeric
avo$AveragePrice<-as.numeric(avo$AveragePrice)
#test assumptions
plotNormalHistogram(avo$AveragePrice)
avo$AveragePriceSQRT=sqrt(avo$AveragePrice)
plotNormalHistogram(avo$AveragePriceSQRT)
avo$AveragePriceLOG=log(avo$AveragePrice)
plotNormalHistogram(avo$AveragePriceLOG)

#Homogeneity of Variance
bartlett.test(AveragePriceSQRT~region, data=avo)

#ANOVA

avo1=lm(AveragePriceSQRT~region,data=avo)
Anova(avo1, Type="II", white.adjust=TRUE)

pairwise.t.test(avo$AveragePriceSQRT, avo$region, p.adjust = "bonferroni", pool.sd = FALSE)

avoMeans=avo %>% group_by(region) %>% summarize(Mean=mean(AveragePrice))
avoMeans

#the avaerage price have different outcome among all regions.Albany has an avaerage price of $1.56








